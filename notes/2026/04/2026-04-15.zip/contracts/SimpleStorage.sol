// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract SimpleStorage {
    uint256 private storedValue;
    address private owner;

    event ValueChanged(uint256 indexed newValue, address indexed changer);

    modifier onlyOwner() {
        require(msg.sender == owner, "Only owner can call this function");
        _;
    }

    constructor() {
        owner = msg.sender;
        storedValue = 0;
    }

    function setValue(uint256 newValue) public onlyOwner {
        storedValue = newValue;
        emit ValueChanged(newValue, msg.sender);
    }

    function getValue() public view returns (uint256) {
        return storedValue;
    }

    function getOwner() public view returns (address) {
        return owner;
    }

    function incrementValue() public onlyOwner {
        storedValue += 1;
        emit ValueChanged(storedValue, msg.sender);
    }

    function decrementValue() public onlyOwner {
        require(storedValue > 0, "Value cannot be negative");
        storedValue -= 1;
        emit ValueChanged(storedValue, msg.sender);
    }
}
